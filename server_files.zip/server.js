import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import productRoutes from './routes/productRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import authRoutes from './routes/authRoutes.js';
import wishlistRoutes from './routes/wishlistRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import imageRoutes from './routes/imageRoutes.js';
import db from './config/db.js';
import analyticsService from './services/analyticsService.js';
import ProductRepository from './repositories/ProductRepository.js';
import { logger } from './utils/logger.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateDocsHTML } from './utils/docsTemplate.js';
import { apiKeyAuth } from './middleware/apiKeyAuth.js';
import { rateLimiter } from './middleware/rateLimiter.js';
import bulkProductRoutes from './routes/bulkProductRoutes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

// Global process error handlers to prevent Passenger 500 crashes
process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION:', err.stack || err.message || err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('UNHANDLED REJECTION at:', promise, 'reason:', reason);
});

const app = express();
app.set('trust proxy', 1); // required for correct IP detection behind Render proxy
const PORT = process.env.PORT || 5000;

// Middleware
const corsOptions = {
  origin: process.env.FRONTEND_URL || '*',
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '250mb', extended: true }));

// Added after middleware block
app.use('/images', express.static(path.join(__dirname, '../public/images')));

// Serve static frontend build
// Always register static middleware; if dist doesn't exist yet it passes through harmlessly
const distPath = path.join(__dirname, '../dist');
app.use(express.static(distPath, { index: 'index.html' }));

// Request Logger
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Apply rate limiting to all API requests
app.use('/api', rateLimiter);

// Apply API Key Authentication to all /api routes (except /api/docs)
app.use('/api', (req, res, next) => {
  if (req.path === '/docs') return next();
  apiKeyAuth(req, res, next);
});

// Routes
app.use('/api/v1/products', productRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/wishlist', wishlistRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/admin', bulkProductRoutes);
app.use('/api/images', imageRoutes);

// Global Error Handler for JSON parsing errors
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    console.error('JSON Parsing Error:', err.message);
    return res.status(400).json({ message: 'Invalid JSON payload received' });
  }
  next();
});

// Health Check
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', message: 'Fashion Redemption Server is running' });
});

// DB Diagnostic — remove this after fixing MySQL
app.get('/db-test', async (req, res) => {
  const config = {
    host: process.env.MYSQL_HOST || '(not set)',
    port: process.env.MYSQL_PORT || '(not set)',
    user: process.env.MYSQL_USER || '(not set)',
    database: process.env.MYSQL_DATABASE || '(not set)',
    NODE_ENV: process.env.NODE_ENV || '(not set)',
    passwordSet: !!process.env.MYSQL_PASSWORD,
    passwordLength: (process.env.MYSQL_PASSWORD || '').length
  };
  try {
    await db.raw('SELECT 1');
    res.json({ status: 'MySQL connected OK', config });
  } catch (err) {
    res.status(500).json({
      status: 'MySQL connection FAILED',
      error: {
        message: err.message,
        code: err.code,
        errno: err.errno,
        sqlState: err.sqlState
      },
      config
    });
  }
});

// API Documentation Route
app.get('/docs', (req, res) => {
  try {
    const productDocsPath = path.join(__dirname, 'docs', 'PRODUCT_API_DOCS.md');
    const aiDocsPath = path.join(__dirname, 'docs', 'AI_BOT_INTEGRATION.md');

    const productDocs = fs.readFileSync(productDocsPath, 'utf8');
    const aiDocs = fs.readFileSync(aiDocsPath, 'utf8');

    const html = generateDocsHTML(productDocs, aiDocs);
    res.send(html);
  } catch (err) {
    logger.error('Failed to serve documentation', { error: err.message });
    res.status(500).send('Documentation not available. Please ensure .md files exist in server/docs/');
  }
});

app.get('/api/docs', (req, res) => res.redirect('/docs'));

// Seed endpoint (call once to add products with Google Drive images)
app.post('/api/seed-products', async (req, res) => {
  try {
    // Check if products already exist
    const existing = await ProductRepository.getAll({});
    if (existing.products && existing.products.length > 0) {
      return res.json({ status: 'Products already exist in database', count: existing.total });
    }

    // Import products from bulkAddProducts
    const module = await import('./scripts/bulkAddProducts.js');
    const { productsToSeed } = module;

    // Add each product
    let added = 0;
    for (const product of productsToSeed) {
      try {
        // Convert Google Drive links
        let imageUrl = product.images[0];
        if (imageUrl && imageUrl.includes('drive.google.com')) {
          let fileId = '';
          if (imageUrl.includes('/file/d/')) {
            fileId = imageUrl.split('/file/d/')[1].split('/')[0];
          } else if (imageUrl.includes('id=')) {
            fileId = imageUrl.split('id=')[1].split('&')[0];
          }
          imageUrl = fileId ? `https://lh3.googleusercontent.com/d/${fileId}` : imageUrl;
        }

        await ProductRepository.create({
          ...product,
          images: [imageUrl]
        });
        added++;
      } catch (err) {
        logger.error(`Failed to add product: ${product.name}`, { error: err.message });
      }
    }

    res.json({ status: 'Seeding completed', added });
  } catch (err) {
    logger.error('Seed endpoint failed', { error: err.message });
    res.status(500).json({ error: err.message });
  }
  
});

// SPA Catch-all fallback for client-side routing
// Express 5: '/*splat' does NOT match bare '/' so we register both explicitly.
const spaHandler = (req, res, next) => {
  if (req.path.startsWith('/api') || req.path === '/health' || req.path === '/docs' || req.path.startsWith('/images')) {
    return next();
  }
  const indexPath = path.join(distPath, 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  // dist not uploaded yet — show a holding page instead of 404
  res.status(200).send('<!DOCTYPE html><html><head><title>Fashion Redemption</title></head><body><h1>Fashion Redemption Server is running</h1><p>Frontend build pending upload.</p></body></html>');
};

app.get('/', spaHandler);
app.get('/*splat', spaHandler);

// Start Server
app.listen(PORT, async () => {
  console.log(`Server is running on port ${PORT}`);
  console.log('Using MySQL (Transactional) and DuckDB (Analytics)');
  
  // Asynchronous non-blocking background initialization
  setTimeout(async () => {
    // Run Migrations in Production
    if (process.env.NODE_ENV === 'production' || process.env.DATABASE_URL) {
      try {
        console.log('--- PRODUCTION DATABASE SYNC ---');
        console.log('Checking for pending migrations...');
        const [batchNo, appliedMigrations] = await db.migrate.latest();
        if (appliedMigrations.length > 0) {
          console.log(`Success: Applied ${appliedMigrations.length} migrations in batch ${batchNo}`);
          console.log('Updated tables:', appliedMigrations);
        } else {
          console.log('Database is already up to date.');
        }
        console.log('-------------------------------');
      } catch (err) {
        console.error('CRITICAL: Database migration failed on background sync!');
        console.error('Error details:', err.message);
      }
    }

    // Initialize Analytics
    try {
      await analyticsService.syncFromMySQL();
    } catch (err) {
      console.error('Analytics initialization failed:', err.message);
    }
  }, 100);
});

